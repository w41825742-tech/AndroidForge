package id.sinkarm1s.gamingspace;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "GameOverlay")
public class GameOverlayPlugin extends Plugin {
    private static final int OVERLAY_SETTINGS_REQUEST = 6150;

    @PluginMethod
    public void showOverlay(PluginCall call) {
        Context context = getContext();
        if (!Settings.canDrawOverlays(context)) {
            Intent settings = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + context.getPackageName()));
            getActivity().startActivityForResult(settings, OVERLAY_SETTINGS_REQUEST);
            JSObject result = new JSObject();
            result.put("shown", false);
            result.put("permissionRequired", true);
            call.resolve(result);
            return;
        }
        try {
            Intent intent = new Intent(context, GameOverlayService.class);
            intent.setAction(GameOverlayService.ACTION_SHOW);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent);
            else context.startService(intent);
            JSObject result = new JSObject();
            result.put("shown", true);
            result.put("permissionRequired", false);
            call.resolve(result);
        } catch (Exception error) {
            call.reject("Floating panel gagal dijalankan: " + error.getMessage(), error);
        }
    }

    @PluginMethod
    public void hideOverlay(PluginCall call) {
        getContext().stopService(new Intent(getContext(), GameOverlayService.class));
        JSObject result = new JSObject();
        result.put("hidden", true);
        call.resolve(result);
    }

    @PluginMethod
    public void hasOverlayPermission(PluginCall call) {
        JSObject result = new JSObject();
        result.put("granted", Settings.canDrawOverlays(getContext()));
        call.resolve(result);
    }

    @PluginMethod
    public void consumePendingAction(PluginCall call) {
        Context context = getContext();
        String action = context.getSharedPreferences(GameOverlayService.PREFS, Context.MODE_PRIVATE)
                .getString(GameOverlayService.PENDING_ACTION, "");
        context.getSharedPreferences(GameOverlayService.PREFS, Context.MODE_PRIVATE)
                .edit().remove(GameOverlayService.PENDING_ACTION).apply();
        JSObject result = new JSObject();
        result.put("action", action);
        call.resolve(result);
    }
}
