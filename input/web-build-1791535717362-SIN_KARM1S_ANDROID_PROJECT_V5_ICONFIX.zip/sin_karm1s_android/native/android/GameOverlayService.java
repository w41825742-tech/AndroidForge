package id.sinkarm1s.gamingspace;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class GameOverlayService extends Service {
    public static final String ACTION_SHOW = "id.sinkarm1s.gamingspace.SHOW_OVERLAY";
    public static final String PREFS = "sin_karm1s_overlay";
    public static final String PENDING_ACTION = "pending_action";
    private static final String CHANNEL_ID = "sin_karm1s_game_overlay";
    private static final int NOTIFICATION_ID = 1907;

    private WindowManager windowManager;
    private View overlayView;
    private WindowManager.LayoutParams layoutParams;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        Notification notification = createNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        addOverlay();
        return START_STICKY;
    }

    private void addOverlay() {
        if (overlayView != null) return;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(10), dp(10), dp(10));
        panel.setBackground(background(Color.rgb(18, 17, 23), Color.rgb(83, 28, 41), 18));
        panel.setElevation(dp(12));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setPadding(dp(8), dp(9), dp(5), dp(9));
        header.setBackground(background(Color.rgb(197, 17, 39), Color.rgb(255, 63, 82), 12));
        TextView title = text("SIN KARM1S  /  AX-MODE", 12, Color.WHITE, true);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(30), 1));
        TextView close = text("HIDE", 9, Color.WHITE, true);
        close.setGravity(Gravity.CENTER);
        close.setPadding(dp(7), 0, dp(7), 0);
        header.addView(close, new LinearLayout.LayoutParams(dp(42), dp(30)));
        close.setOnClickListener(v -> stopSelf());
        header.setOnTouchListener(new View.OnTouchListener() {
            private float startX, startY;
            private int initialX, initialY;
            @Override public boolean onTouch(View v, MotionEvent event) {
                if (layoutParams == null || windowManager == null) return false;
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = event.getRawX(); startY = event.getRawY();
                    initialX = layoutParams.x; initialY = layoutParams.y;
                    return true;
                }
                if (event.getAction() == MotionEvent.ACTION_MOVE) {
                    layoutParams.x = Math.max(0, initialX - (int) (event.getRawX() - startX));
                    layoutParams.y = Math.max(0, initialY + (int) (event.getRawY() - startY));
                    try { windowManager.updateViewLayout(overlayView, layoutParams); } catch (Exception ignored) {}
                    return true;
                }
                return event.getAction() == MotionEvent.ACTION_UP;
            }
        });
        panel.addView(header, new LinearLayout.LayoutParams(-1, -2));

        TextView caption = text("QUICK GAME CONTROLS", 9, Color.rgb(224, 178, 187), true);
        caption.setPadding(dp(4), dp(11), dp(4), dp(7));
        panel.addView(caption);

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);
        String[][] actions = {
                {"NETWORK", "network"}, {"TOUCH LAB", "touch"}, {"AIM LAB", "aim"},
                {"SESSION", "session"}, {"DND GUIDE", "dnd"}, {"OPEN APP", "corner"}
        };
        for (String[] action : actions) {
            TextView tile = text(action[0], 9, Color.WHITE, true);
            tile.setGravity(Gravity.CENTER);
            tile.setPadding(dp(3), dp(8), dp(3), dp(8));
            tile.setBackground(background(Color.rgb(37, 25, 32), Color.rgb(92, 39, 52), 10));
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
            gp.width = 0;
            gp.height = dp(52);
            gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            gp.setMargins(dp(3), dp(3), dp(3), dp(3));
            grid.addView(tile, gp);
            tile.setOnClickListener(v -> openAppForAction(action[1]));
        }
        panel.addView(grid, new LinearLayout.LayoutParams(-1, -2));
        TextView footer = text("DRAG HEADER TO MOVE  •  ANDROID 10+", 8, Color.rgb(135, 128, 140), true);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(8), 0, dp(2));
        panel.addView(footer);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        layoutParams = new WindowManager.LayoutParams(
                dp(276), WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        layoutParams.gravity = Gravity.TOP | Gravity.END;
        layoutParams.x = dp(9);
        layoutParams.y = dp(150);
        overlayView = panel;
        try { windowManager.addView(overlayView, layoutParams); }
        catch (Exception error) { overlayView = null; stopSelf(); }
    }

    private void openAppForAction(String action) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PENDING_ACTION, action).apply();
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (launch == null) {
            launch = new Intent(this, MainActivity.class);
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        launch.putExtra("sin_karm1s_overlay_action", action);
        startActivity(launch);
    }

    private Notification createNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("SIN KARM1S AX-MODE")
                    .setContentText("Floating gaming control panel aktif")
                    .setSmallIcon(android.R.drawable.ic_media_play)
                    .setOngoing(true)
                    .build();
        }
        return new Notification.Builder(this)
                .setContentTitle("SIN KARM1S AX-MODE")
                .setContentText("Floating gaming control panel aktif")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Game Corner floating panel", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Notifikasi selama panel gaming melayang aktif");
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return view;
    }

    private GradientDrawable background(int fill, int stroke, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radius));
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override
    public void onDestroy() {
        if (windowManager != null && overlayView != null) {
            try { windowManager.removeView(overlayView); } catch (Exception ignored) {}
        }
        overlayView = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE);
        else stopForeground(true);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
