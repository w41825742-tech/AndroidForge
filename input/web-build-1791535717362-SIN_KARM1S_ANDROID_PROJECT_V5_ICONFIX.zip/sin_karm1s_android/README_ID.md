# SIN KARM1S Gaming Space — proyek PWA + sumber Android

## Perubahan versi ringkas
- Menu utama sekarang berisi **tepat 20 fitur utama**; alat yang sejenis digabung dalam panel kategori agar tidak membingungkan.
- Halaman **GAME CORNER** mengambil inspirasi layout dari referensi: library game, dashboard status yang jujur, modul cepat, dan panel **AX-MODE** merah-putih.
- **AX-MODE** punya panel kontrol di dalam aplikasi dan jalur native Android untuk floating panel di atas game. Pada APK, tombol `AKTIFKAN FLOATING PANEL` akan meminta izin overlay; setelah diizinkan, panel bisa digeser dan shortcut-nya membuka modul terkait. Fitur native ini tetap harus diuji pada perangkat asli.
- Nama aplikasi Android dan label di Setelan: **SIN KARM1S**. Ikon launcher native menggunakan logo SIN KARM1S yang kamu kirim.
- Nama aplikasi Android dan label di Setelan: **SIN KARM1S**. Ikon launcher native menggunakan logo SIN KARM1S yang kamu kirim.
- Ikon grafis PNG digunakan pada UI; tidak memakai emoji.
- Alat lama yang berguna dipertahankan di dalam kelompok: network/ping, monitor browser, checklist pra-match, touch-test, aim/reaction, catatan sensitivity/HUD, audio, timer, riwayat, analitik match, rencana latihan, tes layar, perawatan perangkat, catatan, dan backup/restore.

## Cara memakai preview / PWA di Android
1. Untuk preview lokal, buka `index.html` setelah mengekstrak ZIP.
2. Untuk memasang sebagai aplikasi web, upload **isi folder proyek** ke hosting HTTPS (contohnya Netlify).
3. Buka URL dari Chrome Android, buka menu tiga titik, lalu pilih **Instal aplikasi** atau **Tambahkan ke layar utama** jika tersedia.
4. Data disimpan pada perangkat/browser yang digunakan. Ekspor backup JSON secara berkala agar tidak hilang ketika data browser dibersihkan.

## Membangun APK native untuk Android 10 ke atas
1. Pada komputer, instal Node.js LTS, Java 17, Android Studio, dan Android SDK/Build Tools.
2. Ekstrak ZIP dan jalankan `npm install`, kemudian `npm test`.
3. Jalankan `npm run android:add` satu kali untuk membuat project native, menetapkan minimum Android API 29, serta memasang plugin/service floating overlay.
4. Untuk sinkronisasi source, jalankan `npm run android:sync`; untuk APK debug, jalankan `npm run android:build`.
5. APK debug adalah untuk pengujian. APK release membutuhkan signing yang dibuat sendiri.

### Build melalui GitHub Actions
1. Upload seluruh isi proyek ke repository GitHub.
2. Buka tab **Actions**, pilih **Build SIN KARM1S Android APK**, lalu pilih **Run workflow**.
3. Jika workflow sukses, unduh artifact `SIN-KARM1S-Android10-debug-apk` dan ekstrak `app-debug.apk`.

## Batasan yang perlu diketahui
- Proyek ZIP belum membawa APK final yang sudah dibuild dan dites secara fisik.
- Floating panel merupakan fitur APK native yang meminta izin `Tampil di atas aplikasi lain`. PWA/preview hanya menampilkan AX-MODE di dalam aplikasi. Panel ini menyediakan shortcut; bukan pengubah RAM, suhu, FPS, atau ping game secara otomatis.
- Tes ping mengukur request dari browser, bukan ping ke server game. Refresh/FPS mengukur tab aplikasi, bukan FPS Free Fire.
- Status baterai bergantung pada dukungan browser/API. Game launcher berusaha membuka package ID yang disimpan, tetapi keberhasilan tergantung package ID, browser, dan perangkat.
- Mikrofon hanya aktif setelah pengguna menekan tombol dan menyetujui izin; audio tidak diunggah oleh aplikasi.

## Data
Library game, catatan, checklist, profil, statistik, dan riwayat sesi tersimpan pada `localStorage` perangkat/browser. Tidak ada sinkronisasi akun/server pada versi ini. Gunakan menu **Backup & Restore** untuk membuat dan memulihkan file JSON.
